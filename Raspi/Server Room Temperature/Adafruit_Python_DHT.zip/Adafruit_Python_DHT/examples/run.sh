#!/bin/bash
sudo /home/pi/Adafruit_Python_DHT/examples/AdafruitDHT.py 2302 4 > /home/pi/temp/temp.txt
#script to dump temp and humidity to temp.txt file
